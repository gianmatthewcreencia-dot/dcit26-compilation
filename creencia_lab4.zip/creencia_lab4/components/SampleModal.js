
import React from 'react';
import {
  View,
  Text,
  Image,
  Modal,
  ScrollView,
  Button,
  StyleSheet
} from 'react-native';

export default function SampleModal({ visible, onClose }) {
  return (
    <Modal
      visible={visible}
      animationType="slide"
      onRequestClose={onClose}
    >
      <View style={styles.container}>

        <Image
          source={require('../assets/CATS.png')}
          style={styles.image}
          resizeMode="contain"
        />

        <ScrollView style={styles.scroll}>
          <Text style={styles.title}>Fun Facts About Cats and Cat Memes!</Text>
          <Text style={styles.text}>
            Cats are fascinating creatures with many fun and surprising facts! 
            Did you know that cats spend around 12–16 hours sleeping every day? 
            They can rotate their ears up to 180 degrees to hear sounds better, 
            and their noses have unique patterns, just like human fingerprints. 
            Cats also use their whiskers to sense their surroundings and determine 
            whether they can fit through small spaces.
            
            {'\n\n'}

            Interestingly, cats are also one of the most popular animals on the 
            internet, appearing in countless memes because of their funny expressions, 
            unexpected behaviors, dramatic reactions, and silly personalities. Their 
            relatable and sometimes chaotic actions make them perfect for expressing 
            different human emotions and everyday situations. Although they may seem 
            independent, cats can recognize their owners' voices and show affection 
            through purring, headbutting, and slow blinking!
          </Text>
        </ScrollView>

        <View style={styles.button}>
          <Button
            title="Close"
            onPress={onClose}
            color="red"
          />
        </View>

      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#b3d1ff',
    alignItems: 'center',
  },

  image: {
    width: 200,
    height: 180,
    marginTop: 30,
    marginBottom: 15,
  },

  scroll: {
    flex: 1,
    width: '100%',
    marginBottom: 15,
  },
  title: {
    fontSize: 20,
    textAlign: 'center',
    paddingBottom: 20,
  },

  text: {
    fontSize: 16,
    textAlign: 'justify',
    lineHeight: 25,
  },

  button: {
    width: '100%',
    marginBottom: 20,
  },
});

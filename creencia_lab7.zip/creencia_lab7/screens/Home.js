import React, { useState, useEffect } from 'react';

import {
  View,
  Text,
  Image,
  TouchableOpacity,
  ActivityIndicator,
  StyleSheet,
} from 'react-native';

export default function Home({ navigation }) {

  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(false);

  const fetchUser = async () => {
    try {
      setLoading(true);

      const response = await fetch(
        'https://randomuser.me/api'
      );

      const data = await response.json();

      setUser(data.results[0]);

    } catch (error) {
      alert('Failed to fetch user. Please try again.');

    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUser();
  }, []);

  return (
    <View style={styles.container}>

      <Text style={styles.heading}>
        Random User
      </Text>

      {loading ? (
        <ActivityIndicator size="large" color="#878672" />
      ) : user ? (

        <View style={styles.card}>

          <TouchableOpacity
            onPress={() =>
              navigation.navigate('Profile', { user: user })
            }
          >
            <Image
              source={{ uri: user.picture.large }}
              style={styles.image}
            />
          </TouchableOpacity>

          <Text style={styles.name}>
            {user.name.title}. {user.name.first} {user.name.last}
          </Text>

          <Text style={styles.gender}>
            {user.gender}
          </Text>

          <TouchableOpacity
            style={styles.button}
            onPress={fetchUser}
          >
            <Text style={styles.buttonText}>
              Generate Another User
            </Text>
          </TouchableOpacity>

        </View>

      ) : (
        <Text>Unable to load user.</Text>
      )}

    </View>
  );
}

const styles = StyleSheet.create({

  container: {
    flex: 1,
    backgroundColor: '#F3F2FF',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },

  heading: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#878672',
    marginBottom: 25,
  },

  card: {
    backgroundColor: '#FFFFFF',
    width: '100%',
    alignItems: 'center',
    padding: 25,
    borderRadius: 20,
    elevation: 5,
  },

  image: {
    width: 160,
    height: 160,
    borderRadius: 80,
    marginBottom: 20,
    borderWidth: 4,
    borderColor: '#878672',
  },

  name: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#333333',
    textAlign: 'center',
  },

  gender: {
    fontSize: 15,
    color: '#777777',
    marginTop: 8,
    marginBottom: 25,
    textTransform: 'capitalize',
  },

  button: {
    backgroundColor: '#878672',
    padding: 15,
    borderRadius: 12,
    width: '100%',
    alignItems: 'center',
  },

  buttonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 16,
  },

});

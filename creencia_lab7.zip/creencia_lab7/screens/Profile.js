import React from 'react';

import {
  View,
  Text,
  Image,
  ScrollView,
  StyleSheet,
} from 'react-native';

export default function Profile({ route }) {

  const { user } = route.params;

  const birthday = new Date(user.dob.date).toLocaleString();

  const registered = new Date(user.registered.date).toLocaleString();

  const address =
    `${user.location.street.number} ${user.location.street.name}, ` +
    `${user.location.city}, ${user.location.state}, ` +
    `${user.location.country}, ${user.location.postcode}`;

  return (
    <View style={styles.container}>
    <ScrollView
      style={styles.scrollView}
    contentContainerStyle={styles.scrollContent}
    showsVerticalScrollIndicator={true}
    nestedScrollEnabled={true}
    >

      <View style={styles.header}>

        <Image
          source={{ uri: user.picture.large }}
          style={styles.image}
        />

        <Text style={styles.name}>
          {user.name.first} {user.name.last}
        </Text>

      </View>

      <View style={styles.section}>

        <Text style={styles.sectionTitle}>
          About
        </Text>

        <Text style={styles.label}>
          Age: <Text style={styles.value}>{user.dob.age}</Text>
        </Text>

        <Text style={styles.label}>
          {user.name.title}. {user.name.first} {user.name.last}
        </Text>

        <Text style={styles.label}>
          Birthday: <Text style={styles.value}>{birthday}</Text>
        </Text>

        <Text style={styles.label}>
          Gender: <Text style={styles.value}>{user.gender}</Text>
        </Text>

        <Text style={styles.label}>
          Address: <Text style={styles.value}>{address}</Text>
        </Text>

      </View>

      <View style={styles.section}>

        <Text style={styles.sectionTitle}>
          Contact
        </Text>

        <Text style={styles.label}>
          Email: <Text style={styles.value}>{user.email}</Text>
        </Text>

        <Text style={styles.label}>
          Phone: <Text style={styles.value}>{user.phone}</Text>
        </Text>

      </View>

      <View style={styles.section}>

        <Text style={styles.sectionTitle}>
          Other
        </Text>

        <Text style={styles.label}>
          Date registered: <Text style={styles.value}>{registered}</Text>
        </Text>

      </View>

    </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({

  container: {
    flex: 1,
    backgroundColor: '#F3F2FF',
    overflow: 'auto',
    minHeight: 0,
  },

  scrollView: {
    flex: 1,
    minHeight: 0,
  },

  scrollContent: {
    padding: 20,
    paddingBottom: 40,
    flexGrow: 1,
  },

  header: {
    alignItems: 'center',
    marginBottom: 25,
    padding: 20,
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    elevation: 4,
  },

  image: {
    width: 150,
    height: 150,
    borderRadius: 75,
    borderWidth: 4,
    borderColor: '#878672',
    marginBottom: 15,
  },

  name: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333333',
    textAlign: 'center',
  },

  section: {
    backgroundColor: '#FFFFFF',
    padding: 20,
    borderRadius: 15,
    marginBottom: 18,
    elevation: 3,
  },

  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#878672',
    marginBottom: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#DDDDDD',
    paddingBottom: 10,
  },

  label: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#444444',
    marginBottom: 12,
  },

  value: {
    fontWeight: 'normal',
    color: '#666666',
  },

});

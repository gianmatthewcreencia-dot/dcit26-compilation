import React, { useState } from 'react';
import { View } from 'react-native';

import HomeScreen from './Screens/Home';
import CatsScreen from './Screens/Cats';

export default function App() {
  const [selectedCat, setSelectedCat] = useState(null);

  return (
    <View style={{ flex: 1 }}>
      {selectedCat === null ? (
        <HomeScreen onSelectCat={setSelectedCat} />
      ) : (
        <CatsScreen
          cat={selectedCat}
          onBack={() => setSelectedCat(null)}
        />
      )}
    </View>
  );
}

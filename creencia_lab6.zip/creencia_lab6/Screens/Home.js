import React from 'react';

import { View, Text, FlatList, TouchableOpacity, StyleSheet } from 'react-native';

const cats = [
  {
    key: '1',
    title: 'Maine Coon',
    description: 'The Maine Coon is a large domesticated cat breed. The breed is selectively bred from one of the oldest landraces in North America, and is pedigreed in all major cat registries worldwide. It originated in the U.S. state of Maine, where it is the official state cat.',
    fact: 'Instead of standard meows, they often greet people and ask for things using soft, bird-like chirps and trills.',
    image: 'https://almontecats.com/wp-content/uploads/sites/58681/2026/05/Almontecats.com-Maine-Coon-Photo-24-771x1024.jpg'
  },
  {
    key: '2',
    title: 'Ragdoll',
    description: 'The Ragdoll is a breed of cat with a distinct colorpoint coat and blue eyes. Its morphology is large and weighty, and it has a semi-long and silky soft coat. American breeder Ann Baker developed Ragdolls in the 1960s. They are best known for their docile, placid temperament, and affectionate nature.',
    fact: 'Ragdoll cats are known for going limp and relaxing their muscles when picked up, which is how they got their name from ragdoll toys.',
    image: 'https://almontecats.com/wp-content/uploads/sites/58681/2025/11/cherubim-ragdoll-almontecats.com-2.png'
  },
  {
    key: '3',
    title: 'Persian',
    description: 'The Persian cat, also known as the Persian Longhair or simply Persian, is a long-haired traditional breed of cat characterised by a round face and petite, but not flat and not smashed in, muzzle.',
    fact: 'Persian cats have flat, round faces and long, luxurious coats that require regular grooming to prevent tangles and matting.',
    image: 'https://thumb.wikimedia.org/wikipedia/commons/thumb/8/81/Persialainen.jpg/250px-Persialainen.jpg?utm_source=en.wikipedia.org&utm_campaign=parser&utm_content=thumbnail'
  },
  {
    key: '4',
    title: 'Sphynx',
    description: 'The Sphynx cat also known as the Canadian Sphynx, is a breed of cat known for its lack of fur. Hairlessness in cats is a naturally occurring genetic mutation, and the Sphynx was developed through selective breeding of these animals, starting in the 1960s.',
    fact: 'They may look completely hairless, but their skin is actually covered in a fine layer of peach-fuzz-like hair that feels similar to suede.',
    image: 'https://tica.org/wp-content/uploads/2018/08/Sphynx1-e1730736648691.jpg'
  },
  {
    key: '5',
    title: 'Siamese',
    description: 'The Siamese cat is one of the first distinctly recognised breeds of domestic cat. It is selectively bred since the end of the 19th-century from the Wichianmat landrace, one of several varieties of cats native to Thailand, and is pedigreed in all major cat fancier and breeder organisations.',
    fact: 'Born almost completely white, these cats gradually develop darker markings on their faces, ears, paws, and tails as they grow.',
    image: 'https://images.litter-robot.com/media/blog/alex-meier-siamese.jpg'
  },
];

export default function HomeScreen({ onSelectCat }) {
  return (
    <View style={styles.container}>

      <Text style={styles.header}>Cat List</Text>

      <FlatList
        data={cats}
        keyExtractor={(item) => item.key}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.catItem}
            onPress={() => onSelectCat(item)}
          >
            <Text style={styles.catText}>
              {item.title}
            </Text>
          </TouchableOpacity>
        )}
      />

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#3073b7',
    padding: 15,
    paddingTop: 45,
  },

  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 15,
    color: '#efefd0'
  },

  catItem: {
    backgroundColor: '#efefd0',
    borderWidth: 1,
    borderColor: '#efefd0',
    padding: 15,
    marginBottom: 10,
    borderRadius: 5
  },

  catText: {
    fontSize: 16,
    color: '#203c7f',
    fontWeight: 'bold',
  }
});

import React from 'react';

import {
  View,
  Text,
  Image,
  TouchableOpacity,
  StyleSheet
} from 'react-native';

export default function CatsScreen({ cat, onBack }) {
  return (
    <View style={styles.container}>

      <TouchableOpacity onPress={onBack}>
        <Text style={styles.backButton}>← Back</Text>
      </TouchableOpacity>

      <Image
        source={{ uri: cat.image }}
        style={styles.catImage}
      />

      <Text style={styles.catInfo}>
        Name: {cat.title}
      </Text>

      <Text style={styles.catInfo}>
        Description: {cat.description}
      </Text>

      <Text style={styles.catInfo}>
        Fun Fact: {cat.fact}
      </Text>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#3073b7',
    padding: 15,
    paddingTop: 45,
  },

  backButton: {
    fontSize: 16,
    color: '#efefd0',
    marginBottom: 15
  },

  catImage: {
    width: 250,
    height: 200,
    resizeMode: 'contain',
    alignSelf: 'center',
    marginBottom: 15,
    resizeMode: 'contain'
  },

  catInfo: {
    fontSize: 16,
    color: '#203c7f',
    backgroundColor: '#efefd0',
    padding: 10,
    marginBottom: 5,
    borderRadius: 5
  }
});

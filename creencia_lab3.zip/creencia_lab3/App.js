import React, {useState} from 'react';

import {Text, View, TextInput, TouchableOpacity, FlatList, StyleSheet} from 'react-native';
export default function App() {
  const [item, setItem] = useState('');
  const [items, setItems] = useState([]);
  const colorsItems = ['#078D70', '#26CEAA', '#98E8C1', '#FFFFFF', '#7BADE2', '#5049CC', '#3D1A78'];
  const colorsText = ['#FFFFFF', '#FFFFFF', '#000000', '#000000', '#FFFFFF', '#FFFFFF', '#FFFFFF'];

  const addItem = () => {
    if (item.trim() != '') {
      setItems([...items, item]);
      setItem('');
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.inputBox}>
        <TextInput
          style={styles.input}
          placeholder="Enter Item"
          value={item}
          onChangeText={setItem}
        />
        
        <TouchableOpacity style={styles.button} onPress={addItem}>
          <Text style={styles.buttonText}>ADD</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={items}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item, index }) => (
          <View style={[styles.listItem, { backgroundColor: colorsItems[index % colorsItems.length] }]}>
            <Text style={[styles.itemText, { color: colorsText[index % colorsText.length] }]}>{item}</Text>
          </View>
        )}
      />
    </View>
  );
}

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      padding: 20,
      backgroundColor: '#D5FDFF',
    },

    inputBox: {
      paddingTop: 30,
      flexDirection: 'row',
      marginBottom: 10,
    },

    input: {
      flex: 1,
      backgroundColor: '#FFFFFF',
      borderWidth: 2,
      borderColor: '#888',
      padding: 10,
      marginRight: 8,
      height: 40,
    },

    button: {
      backgroundColor: '#3498DB',
      padding: 10,
      justifyContent: 'center',
      borderRadius: 5,
    },

    buttonText: {
      color: 'white',
      fontWeight: 'bold',
    },

    listItem: {
      padding: 12,
      borderWidth: 1,
      borderColor: '#555',
      marginBottom: 5,
    },

    itemText: {
      fontSize: 16,
    },
  });

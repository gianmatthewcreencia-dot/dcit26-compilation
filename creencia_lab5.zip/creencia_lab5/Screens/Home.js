import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Button } from 'react-native-paper';

export default function HomeScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Button style={styles.button}
        labelStyle={styles.buttonText}
        mode="contained"
        onPress={() => navigation.navigate('Profile')}
      >
        PROFILE
      </Button>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f2edd7',
    justifyContent: 'center',
    alignItems: 'center',
  },

  button: {
    backgroundColor: '#755139',
    color: '#f2edd7',
  },

  buttonText: {
    color: '#f2edd7',
  },
});

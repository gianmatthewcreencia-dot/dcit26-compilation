import React from 'react';
import { createDrawerNavigator } from '@react-navigation/drawer';

import HomeStack from './HomeNavi';
import AboutStack from './AboutNavi';

const Drawer = createDrawerNavigator();

export default function DrawerNavigator() {
  return (
    <Drawer.Navigator
      initialRouteName="HomeStack"
    >
      <Drawer.Screen
        name="HomeStack"
        component={HomeStack}
        options={{
          title: 'Home',
          headerShown: false,
        }}
      />

      <Drawer.Screen
        name="AboutStack"
        component={AboutStack}
        options={{
          title: 'About',
          headerShown: false,
        }}
      />
    </Drawer.Navigator>
  );
}

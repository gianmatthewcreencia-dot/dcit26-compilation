import React from 'react';

import { Text, View, StyleSheet } from 'react-native';
export default function App() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Student Profile</Text>

      <Text style={styles.label}>Name:</Text>
      <Text style={styles.info}>Gian Matthew Creencia</Text>

      <Text style={styles.label}>Age:</Text>
      <Text style={styles.info}>20</Text>

      <Text style={styles.label}>Course/Year/Section:</Text>
      <Text style={styles.info}>BS Computer Science, 3rd Year, Section 5</Text>

      <Text style={styles.label}>About Me:</Text>
      <Text style={styles.info}>Eager about learning and improving my skills. I have interest in web development and game development.</Text>

      <Text style={styles.label}>Achievements</Text>
      <Text style={styles.info}>Nakaabot ng 3rd Year HAHAHA</Text>

      <Text style={styles.label}>Skills</Text>
      <Text style={styles.info}>Basic Web Development</Text>
      <Text style={styles.info}>Basic 3D Modelling</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container : {
    flex: 1,
    padding: 20,
    backgroundColor: '#F5FDFF'
  },
  title: {
    fontSize: 30,
    paddingTop: 30,
    paddingBottom: 5,
    textAlign: 'center'
  },
  label : {
    fontSize: 25,
    paddingTop: 10
  },
  info: {
    fontSize: 23
  }
});

